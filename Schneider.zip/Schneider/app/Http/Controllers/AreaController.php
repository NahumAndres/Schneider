<?php

namespace Schneider\Http\Controllers;

use Illuminate\Http\Request;

use Schneider\Http\Requests;

use Schneider\Area;

class AreaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      //show data
      $areas = Area::all();
      return view('area.index',['areas' => $areas]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      //create new user
      return view('area.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      //validation
      $this->validate($request, [
        'codigo'=>'required',
        'nombre'=>'required'
      ]);
      //create new user
      $area = new area;
      $area->codigo = $request->codigo;
      $area->nombre = $request->nombre;
      $area->save();
      return redirect()->route('area.index')->with('alert-succes', 'Data Has been Saved!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      //
      $area = Area::findOrFail($id);
      //return to the edit views
      return view('area.edit',compact('area'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      //validation
      $this->validate($request, [
        'codigo'=>'required',
        'nombre'=>'required'
      ]);

      $area = Area::findOrFail($id);
      $area->codigo = $request->codigo;
      $area->nombre = $request->nombre;
      $area->save();

      return redirect()->route('area.index')->with('alert-succes', 'Data Has been Saved!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      //Destroy user
      $area = Area::findOrFail($id);
      $area->delete();
      return redirect()->route('area.index')->with('alert-succes', 'Data Has been delete!');
    }
}
