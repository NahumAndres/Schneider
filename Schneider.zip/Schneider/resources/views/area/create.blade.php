@extends('master')
	@section('content')
	<div class="row">
		<div class="col-md-12">
			<h1>Create Area</h1>
		</div>
	</div>
  <div class="row">
    <div class="col-md-12">
      <form class="" action="{{route('area.store')}}" method="post">
        {{csrf_field()}}
        <div class="form-group{{ ($errors->has('codigo')) ? $errors->first('title') : ''}}">
          <input type="text" name="codigo" class="form-control" placeholder="Enter Code Here">
          {!! $errors->first('codigo',' <p class="help-block">:message</p>') !!}
        </div>
        <div class="form-group{{ ($errors->has('nombre')) ? $errors->first('title') : ''}}">
          <input type="text" name="nombre" class="form-control" placeholder="Enter Name Here">
          {!! $errors->first('nombre',' <p class="help-block">:message</p>') !!}
        </div>

        <div class="form-group">
          <input type="submit" class="btn btn-primary" value="save">
        </div>
      </form>
    </div>
  </div>
	@stop
