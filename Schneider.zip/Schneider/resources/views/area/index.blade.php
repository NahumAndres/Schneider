@extends('master')
	@section('content')
	<div class="row">
		<div class="col-md-12">
			<h1>Areas</h1>
		</div>
	</div>

  <div class="row">
    <table class="table table-striped">
      <tr>
        <th>No.</th>
        <th>Code</th>
        <th>Name</th>
        <th>Actions</th>
      </tr>

      <a href="{{route('area.create')}}" class="btn btn-info pull-right">New Area</a>
      <br>
        <br>
      <?php $no=1; ?>

      @foreach($areas as $area)
        <tr>
          <td>{{$no++}}</td>
          <td>{{$area->codigo}}</td>
          <td>{{$area->nombre}}</td>
          <td>
            <form class="" action="{{route('area.destroy',$area->id)}}" method="post">
              <input type="hidden" name="_method" value="delete">
              <input type="hidden" name="_token" value="{{ csrf_token() }}">
              <a href="{{route('area.edit',$area->id)}}" class="btn btn-primary">Edit</a>
              <input type="submit" class="btn btn-danger" onclick="return confirm('Are you sure to delete this area');" name="name" value="delete">
            </form>

          </td>
        </tr>

      @endforeach

    </table>
  </div>


	@stop
