@extends('master')
	@section('content')
	<div class="row">
		<div class="col-md-12">
			<h1>Edit User</h1>
		</div>
	</div>
  <div class="row">
    <form class="" action="{{route('usuario.update',$usuario->id)}}" method="post">
      <input name="_method" type="hidden" value="PATCH">
      {{csrf_field()}}
      <div class="form-group{{ ($errors->has('name')) ? $errors->first('title') : ''}}">
        <input type="text" name="name" class="form-control" placeholder="Enter Name Here" value="{{$usuario->name}}">
        {!! $errors->first('name',' <p class="help-block">:message</p>') !!}
      </div>
      <div class="form-group{{ ($errors->has('lastName')) ? $errors->first('title') : ''}}">
        <input type="text" name="lastName" class="form-control" placeholder="Enter Lastname Here" value="{{$usuario->lastName}}">
        {!! $errors->first('lastName',' <p class="help-block">:message</p>') !!}
      </div>
      <div class="form-group{{ ($errors->has('user')) ? $errors->first('title') : ''}}">
        <input type="text" name="user" class="form-control" placeholder="Enter User Here" value="{{$usuario->user}}">
        {!! $errors->first('user',' <p class="help-block">:message</p>') !!}
      </div>
      <div class="form-group{{ ($errors->has('password')) ? $errors->first('title') : ''}}">
        <input type="text" name="password" class="form-control" placeholder="Enter Password Here" value="{{$usuario->password}}">
        {!! $errors->first('password',' <p class="help-block">:message</p>') !!}
      </div>
      <div class="form-group">
        <input type="submit" class="btn btn-primary" value="save">
      </div>
    </form>
  </div>






	@stop
