	<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<h1>Edit User</h1>
		</div>
	</div>
  <div class="row">
    <form class="" action="<?php echo e(route('usuario.update',$usuario->id)); ?>" method="post">
      <input name="_method" type="hidden" value="PATCH">
      <?php echo e(csrf_field()); ?>

      <div class="form-group<?php echo e(($errors->has('name')) ? $errors->first('title') : ''); ?>">
        <input type="text" name="name" class="form-control" placeholder="Enter Name Here" value="<?php echo e($usuario->name); ?>">
        <?php echo $errors->first('name',' <p class="help-block">:message</p>'); ?>

      </div>
      <div class="form-group<?php echo e(($errors->has('lastName')) ? $errors->first('title') : ''); ?>">
        <input type="text" name="lastName" class="form-control" placeholder="Enter Lastname Here" value="<?php echo e($usuario->lastName); ?>">
        <?php echo $errors->first('lastName',' <p class="help-block">:message</p>'); ?>

      </div>
      <div class="form-group<?php echo e(($errors->has('user')) ? $errors->first('title') : ''); ?>">
        <input type="text" name="user" class="form-control" placeholder="Enter User Here" value="<?php echo e($usuario->user); ?>">
        <?php echo $errors->first('user',' <p class="help-block">:message</p>'); ?>

      </div>
      <div class="form-group<?php echo e(($errors->has('password')) ? $errors->first('title') : ''); ?>">
        <input type="text" name="password" class="form-control" placeholder="Enter Password Here" value="<?php echo e($usuario->password); ?>">
        <?php echo $errors->first('password',' <p class="help-block">:message</p>'); ?>

      </div>
      <div class="form-group">
        <input type="submit" class="btn btn-primary" value="save">
      </div>
    </form>
  </div>






	<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>