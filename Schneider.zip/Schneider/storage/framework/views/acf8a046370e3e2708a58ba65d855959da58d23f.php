	<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<h1>Users</h1>
		</div>
	</div>

  <div class="row">
    <table class="table table-striped">
      <tr>
        <th>No.</th>
        <th>Name</th>
        <th>Last Name</th>
        <th>User</th>
        <th>Password</th>
        <th>Actions</th>
      </tr>

      <a href="<?php echo e(route('usuario.create')); ?>" class="btn btn-info pull-right">New User</a>
      <br>
        <br>
      <?php $no=1; ?>

      <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
          <td><?php echo e($no++); ?></td>
          <td><?php echo e($usuario->name); ?></td>
          <td><?php echo e($usuario->lastName); ?></td>
          <td><?php echo e($usuario->user); ?></td>
          <td><?php echo e($usuario->password); ?></td>
          <td>
            <form class="" action="<?php echo e(route('usuario.destroy',$usuario->id)); ?>" method="post">
              <input type="hidden" name="_method" value="delete">
              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
              <a href="<?php echo e(route('usuario.edit',$usuario->id)); ?>" class="btn btn-primary">Edit</a>
              <input type="submit" class="btn btn-danger" onclick="return confirm('Are you sure to delete this user');" name="name" value="delete">
            </form>

          </td>
        </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    </table>
  </div>


	<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>